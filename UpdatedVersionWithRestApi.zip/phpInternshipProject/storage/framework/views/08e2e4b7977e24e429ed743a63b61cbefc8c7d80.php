<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | CodingNepal</title>
  <link rel="stylesheet" href="<?php echo e(asset('frontend/css/index.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <style>
     
  </style>
</head>
<body>
    <div class="nav">
        <div class="log">
            <span>Logo</span>
        </div>
        <div class="nav-links">
            <ul>
                <li><a href="/">Home</a></li>
                <li><a href="<?php echo e(route('auth.register')); ?>">Signup</a></li>
                <li><a href="<?php echo e(route('auth.login')); ?>">Login</a></li>
            </ul>
        </div>
    </div>
  <div class="wrapper">
    <header>Welcome To Project</header>
    <p>Complete custom login and signup system in laravel.</p>
    <img style="max-width:300px;" src="<?php echo e(asset('frontend/img/main.png')); ?>" alt="img" width="100%" height="250px">
    <h3>How to Use:</h3>
    <ul style="list-style-type: circle;margin:auto;width:50%;">
        <li>Register yourself with signup.</li>
        <li>then, Go to login page, login to your account with saved credentials.</li>
        <li>After login, You will be redirected to your dashboard.</li>
        <li>In dashboard, Enjoy the functionalities.</li>
    </ul>
  </div>
  
</body>
</html><?php /**PATH /home/u325494472/domains/applyeasily.in/public_html/internshipproject/myproject/resources/views/welcome.blade.php ENDPATH**/ ?>