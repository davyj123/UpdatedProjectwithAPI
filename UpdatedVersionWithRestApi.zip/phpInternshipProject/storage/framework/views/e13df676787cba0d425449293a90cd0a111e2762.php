<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signup | </title>
  <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
    <div class="nav">
        <div class="log">
            <span>Logo</span>
        </div>
        <div class="nav-links">
            <ul>
                <li><a href="/">Home</a></li>
                <li><a href="<?php echo e(route('auth.login')); ?>">Login</a></li>
            </ul>
        </div>
    </div>
  <div class="wrapper">
    <header>Signup Form</header>
    <form action="<?php echo e(route('auth.save')); ?>" method="post">
        <?php if(Session::get('success')): ?>
        <div class="successtextfield">
           <?php echo e(Session::get('success')); ?>

        </div>
      <?php endif; ?>

      <?php if(Session::get('fail')): ?>
        <div class="errortextfield">
           <?php echo e(Session::get('fail')); ?>

        </div>
      <?php endif; ?>

      <?php echo csrf_field(); ?>
        <div class="field email">
            <div class="input-area">
              <input type="text" name="name" placeholder="Your Name" value="<?php echo e(old('name')); ?>">
              <i class="icon fas fa-user-alt"></i> 
            </div>
            <div class="errortextfield"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
          </div>
      <div class="field email">
        <div class="input-area">
          <input type="text" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>">
          <i class="icon fas fa-envelope"></i>
        </div>
        <div class="errortextfield"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
      </div>
      <div class="field password">
        <div class="input-area">
          <input type="password" name="password" placeholder="Password">
          <i class="icon fas fa-lock"></i>
        </div>
        <div class="errortextfield"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
      </div>
      
      <input type="submit" value="Signup">
    </form>
    <div class="sign-txt">Not yet member? <a href="<?php echo e(route('auth.login')); ?>">Login now</a></div>
  </div>
  
</body>
</html><?php /**PATH D:\Xampp\htdocs\project\resources\views/auth/register.blade.php ENDPATH**/ ?>